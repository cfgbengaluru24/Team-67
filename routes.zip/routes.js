import Dashboard from "views/Dashboard.js";
// import { FaBell } from "react-icons/fa";

import Icons from "views/Icons.js";
import Typography from "views/Typography.js";
import TableList from "views/TableList";
import Notification from "views/Notification";
import UpgradeToPro from "views/Upgrade.js";

var routes = [
  {
    path: "/dashboard",
    name: "Dashboard",
    icon: "nc-icon nc-chart-pie-36",
    component: <Dashboard />,
    layout: "/admin",
  },
  {
    path: "/icons",
    name: "Training",
    icon: "nc-icon nc-hat-3",
    component: <Icons />,
    layout: "/admin",
  },

  {
    path: "/tables",
    name: "Daily Report",
    icon: "nc-icon nc-paper",
    component: <TableList />,
    layout: "/admin",
  },
  {
    path: "/typography",
    name: "Community",
    icon: "nc-icon nc-globe",
    component: <Typography />,
    layout: "/admin",
  },
  {
    path: "/notifications",
    name: "Notifications",
    icon: "nc-icon nc-bell-55",
    component: <Notification />,
    layout: "/admin",
  },
];
export default routes;

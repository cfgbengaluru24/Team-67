import React from "react";
// Import User component
import User from "./User";
// reactstrap components
import { Card, CardBody, CardFooter, CardTitle, Row, Col } from "reactstrap";

function Dashboard() {
  return (
    <>
      <div className="content">
        {/* Cards Section */}
        <Row>
          {/* Attendance card */}
          <Col lg="6" md="12">
            <Card className="card-stats">
              <CardBody>
                <Row>
                  <Col md="4" xs="5">
                    <div className="icon-big text-center icon-warning">
                      <i className="fas fa-user-check"></i>
                    </div>
                  </Col>
                  <Col md="8" xs="7">
                    <div className="numbers">
                      <p className="card-category">Attendance</p>
                      <CardTitle tag="p">90%</CardTitle>
                      <p />
                    </div>
                  </Col>
                </Row>
              </CardBody>
              <CardFooter>
                <hr />
                <div className="stats">
                  <i className="fas fa-sync-alt" /> Update Now
                </div>
              </CardFooter>
            </Card>
          </Col>

          {/* Working Hours card */}
          <Col lg="6" md="12">
            <Card className="card-stats">
              <CardBody>
                <Row>
                  <Col md="4" xs="5">
                    <div className="icon-big text-center icon-warning">
                      <i className="nc-icon nc-time-alarm text-success" />
                    </div>
                  </Col>
                  <Col md="8" xs="7">
                    <div className="numbers">
                      <p className="card-category">Working Hours</p>
                      <CardTitle tag="p">2.5 hours</CardTitle>
                      <p />
                    </div>
                  </Col>
                </Row>
              </CardBody>
              <CardFooter>
                <hr />
                <div className="stats">
                  <i className="fas fa-sync-alt" /> Update Now
                </div>
              </CardFooter>
            </Card>
          </Col>
        </Row>

        {/* User profile section */}
        <div className="profile-section">
          <User />
        </div>
      </div>

      {/* Inline styles for spacing */}
      <style>
        {`
          .profile-section {
            margin-top: 30px; /* Ensures a gap of 30px above the profile section */
          }
          .card-stats {
            margin-bottom: 30px; /* Adjusts the bottom margin if needed */
          }
        `}
      </style>
    </>
  );
}

export default Dashboard;

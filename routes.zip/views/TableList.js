import React, { useState } from "react";
// reactstrap components
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Table,
  Row,
  Col,
  Button,
  Form,
  FormGroup,
  Label,
  Input,
} from "reactstrap";

// Sample data for updates
const sampleUpdates = [
  {
    id: 1,
    category: "Student Progress",
    title: "John's Progress in Math",
    date: "2024-07-27",
    teacher: "Mr. Smith",
    content:
      "John has made significant progress in math. He has completed all assignments on time and his test scores have improved.",
  },
  {
    id: 2,
    category: "Class Activities",
    title: "Science Project Presentation",
    date: "2024-07-26",
    teacher: "Ms. Johnson",
    content:
      "The class will present their science projects tomorrow. Please ensure all materials are prepared and presentations are rehearsed.",
  },
  {
    id: 3,
    category: "Announcements",
    title: "Parent-Teacher Meeting",
    date: "2024-07-25",
    teacher: "Mrs. Lee",
    content:
      "A reminder for the parent-teacher meetings scheduled for next week. Please check the schedule and confirm your availability.",
  },
];

const incomingReports = [
  {
    id: 1,
    date: "2024-07-27",
    teacher: "Mr. Green",
    content:
      "New report about Sarah's performance in the recent math test. Please review.",
  },
  {
    id: 2,
    date: "2024-07-26",
    teacher: "Ms. Adams",
    content:
      "Report regarding upcoming field trip details. Confirm the participation of students.",
  },
];

function TableList() {
  const [updates, setUpdates] = useState(sampleUpdates);
  const [newUpdate, setNewUpdate] = useState({
    category: "",
    title: "",
    date: "",
    teacher: "",
    content: "",
  });
  const [editingUpdate, setEditingUpdate] = useState(null);
  const [incoming, setIncoming] = useState(incomingReports);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewUpdate({ ...newUpdate, [name]: value });
  };

  const handleCreateUpdate = () => {
    setUpdates([...updates, { ...newUpdate, id: updates.length + 1 }]);
    setNewUpdate({
      category: "",
      title: "",
      date: "",
      teacher: "",
      content: "",
    });
  };

  const handleEditUpdate = (update) => {
    setEditingUpdate(update);
    setNewUpdate(update);
  };

  const handleUpdateUpdate = () => {
    setUpdates(updates.map((u) => (u.id === editingUpdate.id ? newUpdate : u)));
    setNewUpdate({
      category: "",
      title: "",
      date: "",
      teacher: "",
      content: "",
    });
    setEditingUpdate(null);
  };

  const handleDeleteUpdate = (id) => {
    setUpdates(updates.filter((update) => update.id !== id));
  };

  return (
    <>
      <div className="content">
        <Row>
          <Col md="12">
            <Card>
              <CardHeader>
                <CardTitle tag="h4">Daily Reports</CardTitle>
                <p className="card-category">
                  Manage updates related to student progress, class activities,
                  and announcements.
                </p>
              </CardHeader>
              <CardBody>
                <Row>
                  <Col md="6">
                    <Card>
                      <CardHeader>
                        <CardTitle tag="h4">
                          {editingUpdate
                            ? "Update Report"
                            : "Create New Update"}
                        </CardTitle>
                      </CardHeader>
                      <CardBody>
                        <Form>
                          <FormGroup>
                            <Label for="updateCategory">Category</Label>
                            <Input
                              type="select"
                              id="updateCategory"
                              name="category"
                              value={newUpdate.category}
                              onChange={handleInputChange}
                            >
                              <option value="">Select Category</option>
                              <option value="Student Progress">
                                Student Progress
                              </option>
                              <option value="Class Activities">
                                Class Activities
                              </option>
                              <option value="Announcements">
                                Announcements
                              </option>
                            </Input>
                          </FormGroup>
                          <FormGroup>
                            <Label for="updateTitle">Title</Label>
                            <Input
                              type="text"
                              id="updateTitle"
                              name="title"
                              value={newUpdate.title}
                              onChange={handleInputChange}
                            />
                          </FormGroup>
                          <FormGroup>
                            <Label for="updateDate">Date</Label>
                            <Input
                              type="date"
                              id="updateDate"
                              name="date"
                              value={newUpdate.date}
                              onChange={handleInputChange}
                            />
                          </FormGroup>
                          <FormGroup>
                            <Label for="updateTeacher">Mentor</Label>
                            <Input
                              type="text"
                              id="updateTeacher"
                              name="teacher"
                              value={newUpdate.teacher}
                              onChange={handleInputChange}
                            />
                          </FormGroup>
                          <FormGroup>
                            <Label for="updateContent">Content</Label>
                            <Input
                              type="textarea"
                              id="updateContent"
                              name="content"
                              value={newUpdate.content}
                              onChange={handleInputChange}
                            />
                          </FormGroup>
                          <Button
                            color="primary"
                            onClick={
                              editingUpdate
                                ? handleUpdateUpdate
                                : handleCreateUpdate
                            }
                          >
                            {editingUpdate ? "Update Update" : "Create Update"}
                          </Button>
                        </Form>
                      </CardBody>
                    </Card>
                  </Col>
                  <Col md="12">
                    <Card className="card-plain">
                      <CardHeader>
                        <CardTitle tag="h4">Updates Table</CardTitle>
                      </CardHeader>
                      <CardBody>
                        <Table responsive>
                          <thead className="text-primary">
                            <tr>
                              <th>Category</th>
                              <th>Title</th>
                              <th>Date</th>
                              <th>Teacher</th>
                              <th>Content</th>
                              <th className="text-right">Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            {updates.map((update) => (
                              <tr key={update.id}>
                                <td>{update.category}</td>
                                <td>{update.title}</td>
                                <td>{update.date}</td>
                                <td>{update.teacher}</td>
                                <td>{update.content}</td>
                                <td className="text-right">
                                  <Button
                                    color="warning"
                                    onClick={() => handleEditUpdate(update)}
                                  >
                                    Edit
                                  </Button>
                                  <Button
                                    color="danger"
                                    onClick={() =>
                                      handleDeleteUpdate(update.id)
                                    }
                                    className="ml-2"
                                  >
                                    Delete
                                  </Button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </Table>
                      </CardBody>
                    </Card>
                  </Col>
                </Row>
              </CardBody>
            </Card>
          </Col>
        </Row>

        {/* Incoming Daily Reports Section */}
        <Row>
          <Col md="12">
            <Card>
              <CardHeader>
                <CardTitle tag="h4">Incoming Daily Reports</CardTitle>
                <p className="card-category">
                  Review and acknowledge new daily reports submitted by other
                  teachers.
                </p>
              </CardHeader>
              <CardBody>
                <Table responsive>
                  <thead className="text-primary">
                    <tr>
                      <th>Date</th>
                      <th>Teacher</th>
                      <th>Content</th>
                      <th className="text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {incoming.map((report) => (
                      <tr key={report.id}>
                        <td>{report.date}</td>
                        <td>{report.teacher}</td>
                        <td>{report.content}</td>
                        <td className="text-right">
                          <Button
                            color="info"
                            onClick={() =>
                              alert("Review functionality not implemented yet")
                            }
                          >
                            Review
                          </Button>
                          {/* Add more actions if needed */}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    </>
  );
}

export default TableList;
